﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNETRealTimeTrigger.Data
{
    public class PMUDataCollection
    {
        public Dictionary<String, List<PMUData>> FDRs = new Dictionary<String, List<PMUData>>();
        public PMUDataCollection() { }
        public PMUDataCollection(PMUDataCollection src) { CopyFrom(src); }

        public void CopyFrom(PMUDataCollection src)
        {
            Clear();
            if (src == null) return;
        }

        public void Clear() { Clear(true); }
        public void Clear(Boolean complete)
        {
        }

        public String ToJSONString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("{");
            sb.Append("}");

            return sb.ToString();
        }
    }
}
