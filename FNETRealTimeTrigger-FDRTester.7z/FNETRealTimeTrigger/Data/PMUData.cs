﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNETRealTimeTrigger.Data
{
    public class PMUData
    {
        public DateTime TimeStamp = DateTime.MinValue;
        public double Frequency = 0.0;
        public double VolAngle = 0.0;
        public float Latitude = 0;
        public float Longitude = 0;
        public bool DataQuality = false;

        public PMUData() { }
        public PMUData(PMUData src) { CopyFrom(src); }

        public void CopyFrom(PMUData src)
        {
            Clear();
            if (src == null) return;
            TimeStamp = src.TimeStamp;
            Frequency = src.Frequency;
            VolAngle = src.VolAngle;
            Latitude = src.Latitude;
            Longitude = src.Longitude;
            DataQuality = src.DataQuality;
        }

        public void Clear() { Clear(true); }
        public void Clear(Boolean complete)
        {
            TimeStamp = DateTime.MinValue;
            Frequency = 0.0;
            VolAngle = 0.0;
            Latitude = 0;
            Longitude = 0;
            DataQuality = false;

        }

        public String ToJSONString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("{");
            sb.Append("\"TimeStamp\":" + TimeStamp);
            sb.Append(",\"Frequency\":" + Frequency);
            sb.Append(",\"VolAngle\":" + VolAngle);
            sb.Append(",\"Latitude\":" + Latitude);
            sb.Append(",\"Longitude\":" + Longitude);
            sb.Append(",\"DataQuality\":" + DataQuality);
            sb.Append("}");

            return sb.ToString();
        }
    }
}

