﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

// using FNETToolbox;
using GSF;
using GSF.IO;                           //for file path
using GSF.TimeSeries;
using GSF.TimeSeries.Adapters;
using GSF.Units.EE;                     //for time ticks
using PhasorProtocolAdapters;
using System.IO;                        //for StreamWriter
using System.Collections.Concurrent;    //for concurrentqueue
using System.Data;
using FNETRealTimeTrigger.Data;

namespace FNETRealTimeTrigger
{
    /// <summary>
    /// Defines the type of frequency excursion detected.
    /// </summary>
    public enum EventType
    {
        /// <summary>
        /// Generation based frequency excursion.
        /// </summary>
        GenerationTrip,
        /// <summary>
        /// Load based frequency excursion.
        /// </summary>
        LoadShedding
    }

    /// <summary>
    /// Represents an algorithm that detects frequency excursions.
    /// </summary>
    [Description("FNETEventTrigger: detects generation trip and load shedding")]
    public class FNETEventTrigger : CalculatedMeasurementBase
    {
        #region [ Members ]
        public const string DefaultEventLocationExeName = "UTKEventTriangulation.exe";

        // Fields in connection string
        private double m_estimateTriggerThreshold;  // Threshold for detecting abnormal excursion in frequency(during m_analysisWindowSize)
        private double m_powerEstimateRatio;        // Ratio(in MWperHz) used to calculate the total estimated MW change from frequency 

        private int m_alarmProhibitPeriod;          // Time period( in seconds) right after one event triggering to forbid another triggering to prevent duplicated alarms
        private int m_analysisWindowSize;           // Size(in seconds) of Moving Analysis Window
        private int m_analysisInterval;             // The number of seconds between adjacent calculations
        private int m_bufferPreSize;                // The size of data buffer before event in second
        private int m_bufferPostSize;               // The size of data buffer after event in second
        private int m_consecutiveDetections;        // Consecutive detections used to determine if the alarm is true or false
 //       private int m_dataReadDurationPeriod;       // Total time period(in seconds) after m_preDataReadPeriod to send to shell for data extraction and further analysis
 //       private int m_eventAmountCutoffThreshold;   // The cutoff threshold(in MW) of the event amount for event alert
        private int m_minimumValidChannels;         // Minimum frequency values needed to perform a valid calculation
        private int m_noDataCheckPeriod;            // Time period(in seconds) to check whether a device stops sending data. If so, the voting and other data structure of this device should be cleared.
 //       private int m_preDataReadPeriod;            // Time period(in seconds) before triggering time to send to shell for data extraction
        private int m_votedDeviceThreshold;         // If the total number of voted devices >= this value, then an event is triggered
        private int m_votingPeriod;                 // Time period(in seconds) to allow voting
        private string m_eventLocationExeName;      // The name of location executable file
 //       private string m_monitoredPowerGrid;        // The acronym of the power grid that this trigger is monitoring


        //fields for triggers
        private bool m_eventFlag;                                 // The flag for event trigger
        private bool m_startedvoting;                             // At least one device has voted for the event(used for testing)
        private int m_alarmProhibitCounter;                       // Counter to prevent duplicated alarms
        private int m_deltaTime;                                  // The DeltaTime to calculate DfDt, this value is always (m_analysisWindowSize(in unit of second) -1)
        private int m_noDataCheckCounter;                         // Counter to check whether it's time to clean up the messy results of some devices that never send data again
        private long m_count;                                     // Published frame count
        private DateTime m_eventTimeStamp;                        // Event time stamp
        private DateTime m_firstTimeStamp;                        // m_timeStamps[0]
        private DateTime m_firstVotingTime;                       // The time that one device initiates the voting
        private List<DateTime> m_timeStamps;                      // Timestamps of frequencies
        private List<MeasurementKey> m_validInputMeasurementKeys; // Valid FDR measurement keys

        private ConcurrentDictionary<uint, bool> m_votedDeviceDictionary;               // Dictionary of devices that vote for events 
        private ConcurrentDictionary<uint, int> m_detectedExcursionsDictionary;         // Number of detected excursions per each device
        private ConcurrentDictionary<uint, Ticks> m_lastTimestampDictionary;            // Dictionary of the last timestamp in m_analysisFrequencyDictionary per device
        private ConcurrentDictionary<uint, List<double>> m_analysisFrequencyDictionary; // Frequency of all the signals within analysis window size
        private ConcurrentDictionary<uint, List<Tuple<DateTime,double>>> m_bufferDataDictionary;           // The buffer record a few seconds data pre-disturbance
        
        #endregion

        #region [ Properties ]
        /*
        /// <summary>
        /// Gets or sets  acronym of the power grid that this trigger monitors
        /// 
        /// </summary>
        [ConnectionStringParameter,
        Description("Define acronym of the power grid that this trigger monitors"),
        DefaultValue("EI")]
        public string MonitoredPowerGrid
        {
            get
            {
                return m_monitoredPowerGrid;
            }
            set
            {
                m_monitoredPowerGrid = value;
            }
        }
        */

        /// <summary>
        /// Gets or sets the name of executable event location
        /// 
        /// </summary>
        [ConnectionStringParameter,
       Description("Define the executable used for triangulation location."),
       DefaultValue(DefaultEventLocationExeName)]
        public string EventLocationExeName
        {
            get
            {
                return m_eventLocationExeName;
            }
            set
            {
                m_eventLocationExeName = value;
            }
        }
       /*
        /// <summary>
        /// Gets or sets the amount cut off for output alert. If the estimated amount is smaller than the cutoff, the alert and following program won't be triggered
        /// 
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the cutoff threshold of event amount for event alert, in the unit of MW. Note that this is only for test. It tests the power drop in 4 seconds instead of the whole event"),
        DefaultValue(100)]
        public int EventAmountCutoffThreshold
        {
            get
            {
                return m_eventAmountCutoffThreshold;
            }
            set
            {
                m_eventAmountCutoffThreshold = value;
            }
        }
        */
        //added by Zoe - end*/
        /// <summary>
        /// Gets or sets the threshold for detecting an abnormal excursion in frequency.
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the threshold per SECOND for detecting an abnormal excursion in frequency."),
        DefaultValue(0.0033D)]
        public double EstimateTriggerThreshold
        {
            get
            {
                return m_estimateTriggerThreshold;
            }
            set
            {
                m_estimateTriggerThreshold = value;
            }
        }



        /// <summary>
        /// Gets or sets the number of frames to be analyzed at any given time.
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the number of seconds to be analyzed at any given time. DeltaTime for DfDt analysis is this value minus one."),
        DefaultValue("5")]
        public int AnalysisWindowSize
        {
            get
            {
                return m_analysisWindowSize / FramesPerSecond;
            }
            set
            {
                m_analysisWindowSize = value * FramesPerSecond;
            }
        }

        /// <summary>
        /// Gets or sets the interval between adjacent calculations.
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the number of second between adjacent calculations. The default value is the (frame-rate) defined in the connection string for this Frequency Excursion."),
        DefaultValue("1")]
        public int AnalysisInterval
        {
            get
            {
                return m_analysisInterval / FramesPerSecond;
            }
            set
            {
                m_analysisInterval = value * FramesPerSecond;
            }
        }
        /// <summary>
        /// Gets or sets the length of data buffer pre-disturbance 
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the number of second in buffer before event. The default value is the (frame-rate) defined in the connection string."),
        DefaultValue("15")]
        public int BufferPreSize
        {
            get
            {
                return m_bufferPreSize / FramesPerSecond;
            }
            set
            {
                m_bufferPreSize = value * FramesPerSecond;
            }
        }

        /// <summary>
        /// Gets or sets the length of data buffer post-disturbance 
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the number of second in buffer after event. The default value is the (frame-rate) defined in the connection string."),
        DefaultValue("45")]
        public int BufferPostSize
        {
            get
            {
                return m_bufferPostSize ;
            }
            set
            {
                m_bufferPostSize = value ;
            }
        }
        /// <summary>
        /// Gets or sets the minimum number of consecutive excursions needed in order to trip the alarm.
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the minimum number of consecutive excursions needed in order to trip the alarm."),
        DefaultValue(2)]
        public int ConsecutiveDetections
        {
            get
            {
                return m_consecutiveDetections;
            }
            set
            {
                m_consecutiveDetections = value;
            }
        }

        /// <summary>
        /// Gets or sets the minimum frequency values needed to perform a valid calculation.
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the minimum frequency values needed to perform a valid calculation."),
        DefaultValue(3)]
        public int MinimumValidChannels
        {
            get
            {
                return m_minimumValidChannels;
            }
            set
            {
                m_minimumValidChannels = value;
            }
        }
        /*
        /// <summary>
        /// Gets or sets the ratio used to calculate the total estimated MW change from frequency.
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the ratio used to calculate the total estimated MW change from frequency."),
        DefaultValue(25010.0D)]
        public double PowerEstimateRatio
        {
            get
            {
                return m_powerEstimateRatio;
            }
            set
            {
                m_powerEstimateRatio = value;
            }
        }
        */
        /// <summary>
        /// Gets or sets the period used to prevent duplicate alarms.
        /// </summary>
        [ConnectionStringParameter,
        Description("Define the number of seconds used to prevent duplicate alarms. in unit of second"),
        DefaultValue(60)]
        public int AlarmProhibitPeriod
        {
            get
            {
                return m_alarmProhibitPeriod / FramesPerSecond;
            }
            set
            {
                m_alarmProhibitPeriod = value * FramesPerSecond;
            }
        }

        /// <summary>
        /// Gets or sets the period used to prevent duplicate alarms.
        /// </summary>
        [ConnectionStringParameter,
        Description("if the total number of voted devices >= this value, then an event is triggered"),
        DefaultValue(1)]
        public int VotedDeviceThreshold
        {
            get
            {
                return m_votedDeviceThreshold;
            }
            set
            {
                m_votedDeviceThreshold = value;
            }
        }

        /// <summary>
        /// Gets or sets the period used to allow voting.
        /// </summary>
        [ConnectionStringParameter,
        Description("if the current time - the first voting time >= this value, the previous voting is cleared"),
        DefaultValue(4)]
        public int VotingPeriod
        {
            get
            {
                return m_votingPeriod;
            }
            set
            {
                m_votingPeriod = value;
            }
        }
        /// <summary>
        /// Gets or sets the period used to check whether a device has stopped sending data.
        /// </summary>
        [ConnectionStringParameter,
        Description("the period used to check whether a device has stopped sending data. in seconds"),
        DefaultValue(60)]
        public int NoDataCheckPeriod
        {
            get
            {
                return m_noDataCheckPeriod / FramesPerSecond;
            }
            set
            {
                m_noDataCheckPeriod = value * FramesPerSecond;
            }
        }
        /*
        /// <summary>
        /// Get or set the time period(in seconds) before triggering time to send to shell for data extraction
        ///private int m_DataReadDurationPeriod;    //Total time period(in seconds) after m_preDataReadPeriod to send to shell for data extraction and further analysis
        /// </summary>
        [ConnectionStringParameter,
        Description("time period(in seconds) before triggering time to send to shell for data extraction"),
        DefaultValue(20)]
        public int PreDataReadPeriod
        {
            get
            {
                return m_preDataReadPeriod;
            }
            set
            {
                m_preDataReadPeriod = value;
            }
        }
        */
        /*
        /// <summary>
        ///Get or set total time period(in seconds) after m_preDataReadPeriod to send to shell for data extraction and further analysis
        ///
        /// </summary>
        [ConnectionStringParameter,
        Description("total time period(in seconds) after m_preDataReadPeriod to send to shell for data extraction and further analysis"),
        DefaultValue(80)]
        public int DataReadDurationPeriod
        {
            get
            {
                return m_dataReadDurationPeriod;
            }
            set
            {
                m_dataReadDurationPeriod = value;
            }
        }
        */
        /// <summary>
        /// Returns the detailed status of the <see cref="FrequencyExcursion"/> detector.
        /// </summary>
        public override string Status
        {
            get
            {
                StringBuilder status = new StringBuilder();
       //         status.AppendFormat("      Monitored Power Grid: {0}", m_monitoredPowerGrid);
       //         status.AppendLine();
                status.AppendFormat("Estimate trigger threshold: {0}", m_estimateTriggerThreshold);
                status.AppendLine();
                status.AppendFormat("      Analysis window size: {0}", m_analysisWindowSize);
                status.AppendLine();
                status.AppendFormat("         Analysis interval: {0}", m_analysisInterval);
                status.AppendLine();
                status.AppendFormat("   Detections before alarm: {0}", m_consecutiveDetections);
                status.AppendLine();
                status.AppendFormat(" Minimum valid frequencies: {0}", m_minimumValidChannels);
                status.AppendLine();
                status.AppendFormat("      Power estimate ratio: {0} MW", m_powerEstimateRatio);
                status.AppendLine();
                status.AppendFormat("    Minimum alarm interval: {0} seconds", (int)(m_alarmProhibitPeriod / FramesPerSecond));
                status.AppendLine();

                status.Append(base.Status);

                return status.ToString();
            }
        }

        #endregion

        #region [ Methods ]

        /// <summary>
        /// Initializes the <see cref="FrequencyExcursion"/> detector.
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();

            Dictionary<string, string> settings = Settings;
            string setting;

            // Load required parameters
            /* delected by Ellen, since it is not necessary in this tool
            if (settings.TryGetValue("MonitoredPowerGrid", out setting))
                m_monitoredPowerGrid = setting;
            else
                m_monitoredPowerGrid = "EI";
                */

            if (settings.TryGetValue("estimateTriggerThreshold", out setting))
                m_estimateTriggerThreshold = double.Parse(setting);
            else
                m_estimateTriggerThreshold = 0.0033D;

            if (settings.TryGetValue("analysisWindowSize", out setting))
                m_analysisWindowSize = int.Parse(setting) * FramesPerSecond;
            else
                m_analysisWindowSize = 5 * FramesPerSecond;

            if (settings.TryGetValue("analysisInterval", out setting))
                m_analysisInterval = int.Parse(setting) * FramesPerSecond;
            else
                m_analysisInterval = 1 * FramesPerSecond; 

            if (settings.TryGetValue("bufferPreSize", out setting))
                m_bufferPreSize = int.Parse(setting) * FramesPerSecond;
            else
                m_bufferPreSize = 15 * FramesPerSecond;

            if (settings.TryGetValue("bufferPostSize", out setting))
                m_bufferPostSize = int.Parse(setting);
            else
                m_bufferPostSize = 45;

            if (settings.TryGetValue("consecutiveDetections", out setting))
                m_consecutiveDetections = int.Parse(setting);
            else
                m_consecutiveDetections = 2;

            if (settings.TryGetValue("minimumValidChannels", out setting))
                m_minimumValidChannels = int.Parse(setting);
            else
                m_minimumValidChannels = 3;
            /* delected by Ellen. 
             * in this tool, the amount is not estimated.
            if (settings.TryGetValue("powerEstimateRatio", out setting))
                m_powerEstimateRatio = double.Parse(setting);
            else
                m_powerEstimateRatio = 25010.0D;
             */ 
            if (settings.TryGetValue("alarmProhibitPeriod", out setting))
                m_alarmProhibitPeriod = int.Parse(setting) * FramesPerSecond;
            else
                m_alarmProhibitPeriod = 60 * FramesPerSecond;
            /* delected by Ellen. 
             * in this tool, the amount is not estimated.
            if (settings.TryGetValue("EventAmountCutoffThreshold", out setting))
                m_eventAmountCutoffThreshold = int.Parse(setting);
            else
                m_eventAmountCutoffThreshold = 100;
            */
            if (settings.TryGetValue("VotedDeviceThreshold", out setting))
                m_votedDeviceThreshold = int.Parse(setting);
            else
                m_votedDeviceThreshold = 1;

            if (settings.TryGetValue("VotingPeriod", out setting))
                m_votingPeriod = int.Parse(setting);
            else
                m_votingPeriod = 4;

            if (settings.TryGetValue("NoDataCheckPeriod", out setting))
                m_noDataCheckPeriod = int.Parse(setting) * FramesPerSecond;
            else
                m_noDataCheckPeriod = 60 * FramesPerSecond;
            /* delected by Ellen
             * not used in this tool
            if (settings.TryGetValue("PreDataReadPeriod", out setting))
                m_preDataReadPeriod = int.Parse(setting);
            else
                m_preDataReadPeriod = 20;
            */
            /*
            if (!settings.TryGetValue("DataReadDurationPeriod", out setting))
                m_dataReadDurationPeriod = int.Parse(setting);
            else
                m_dataReadDurationPeriod = 80;
                */
            if (!settings.TryGetValue("eventLocationExeName", out m_eventLocationExeName))
                m_eventLocationExeName = DefaultEventLocationExeName;

            // Use local path if no other path is specified
            m_eventLocationExeName = FilePath.GetAbsolutePath(m_eventLocationExeName);

            if (!File.Exists(m_eventLocationExeName))
                throw new InvalidOperationException($"The event location executable \"{m_eventLocationExeName}\" cannot be found - adapter initialization failed.");

            //added by Zoe to debug - start
            File.AppendAllText(Directory.GetCurrentDirectory() + "FNETEventTriggerRecord.txt", "Initializing Event Trigger \n");
            System.GC.Collect();

       //     string filename = "FNETEventTriggerRecord.txt";
      //      m_csvStream = new StreamWriter(filename, true); //with "true" this enables append
            //added by Zoe to debug - end

            m_startedvoting = false;
            m_eventFlag = false;
            m_eventTimeStamp = DateTime.MinValue;
            m_deltaTime = m_analysisWindowSize / FramesPerSecond - 1;
            
            //added by Zoe to debug - start

       //     m_csvStream.Write("\n m_alarmProhibitPeriod = {0}; m_analysisWindowSize = {1}; m_votingPeriod = {2} \n", m_alarmProhibitPeriod, m_analysisWindowSize, m_votingPeriod);
       //     m_csvStream.Flush();
            //added by Zoe to debug - end

            m_analysisFrequencyDictionary = new ConcurrentDictionary<uint, List<double>>();
            m_bufferDataDictionary = new ConcurrentDictionary<uint, List<Tuple<DateTime, double>>>();
            m_detectedExcursionsDictionary = new ConcurrentDictionary<uint, int>();
            m_votedDeviceDictionary = new ConcurrentDictionary<uint, bool>();
            m_lastTimestampDictionary = new ConcurrentDictionary<uint, Ticks>();

            // m_frequencies = new List<double>();
            m_timeStamps = new List<DateTime>();

            /* delected by Ellen since we don't need it in the open source tool
            //initialize measurement device dictionary
            FNETHistorianInterfaceToolbox tb = new FNETHistorianInterfaceToolbox();
            m_measurementDeviceDictionary = tb.loadDeviceMeasurementDictionary("FREQ", m_monitoredPowerGrid);
            */

            // Validate input measurements
            m_validInputMeasurementKeys = new List<MeasurementKey>();

            for (int i = 0; i < InputMeasurementKeys.Length; i++)
            {
                if (InputMeasurementKeyTypes[i] == SignalType.FREQ)
                    m_validInputMeasurementKeys.Add(InputMeasurementKeys[i]);
            }

            if (m_validInputMeasurementKeys.Count == 0)
                throw new InvalidOperationException("No valid frequency measurements were specified as inputs to the frequency excursion detector.");

            if (m_validInputMeasurementKeys.Count < m_minimumValidChannels)
                throw new InvalidOperationException(string.Format("Minimum valid frequency measurements (i.e., \"minimumValidChannels\") for the frequency excursion detector is currently set to {0}, only {1} {2} defined.", m_minimumValidChannels, m_validInputMeasurementKeys.Count, (m_validInputMeasurementKeys.Count == 1 ? "was" : "were")));

            // Make sure only frequencies are used as input
            InputMeasurementKeys = m_validInputMeasurementKeys.ToArray();             
        }

        //customized dispose method - start

        private bool m_disposed;

        protected override void Dispose(bool disposing)
        {
            if (!m_disposed)
            {
                try
                {
                    // This will be done regardless of whether
                    // the object is finalized or disposed.

                    if (disposing)
                    {
                        // This will be done only when the object
                        // is disposed by calling Dispose().
                        
                        File.AppendAllText(Directory.GetCurrentDirectory() + "FNETEventTriggerRecord.txt", "Dispose Event Trigger \n\n\n");
                        System.GC.Collect();
                    }
                }
                finally
                {
                    m_disposed = true;        // Prevent duplicate dispose.
                    base.Dispose(disposing);  // Call base class Dispose().
                }
            }
        }
        //customized dispose methiod - end
        /* 
                //to exclude islanding units for event detection - start
                public override void QueueMeasurementsForProcessing(IMeasurement measurement)
                {
                    QueueMeasurementsForProcessing(new IMeasurement[] { measurement });
                }


                //filter measurement to exclude the devices that are islanding
                public override void QueueMeasurementsForProcessing(IEnumerable<IMeasurement> measurements)
                {

                    // Remove signals from processing where the device is islanded.
                    //base.QueueMeasurementsForProcessing(measurements.Where(m => !BelongToIslandingDevice(m)));


                    List<IMeasurement> inputMeasurements = new List<IMeasurement>();
                    foreach (IMeasurement measurement in measurements)
                    {
                        bool islanding = BelongToIslandingDevice(measurement);
                        if (!islanding)
                        {

                            inputMeasurements.Add(measurement);
                        }

                    }

                    if (inputMeasurements.Count > 0)
                        SortMeasurements(inputMeasurements);

                }

               private bool BelongToIslandingDevice(IMeasurement m)
                {

                    uint measurementID = m.Key.ID;

                    List<string> islandingDeviceList;
                    if (FNETIslandingTrigger.g_IslandingDeviceDictionary.TryGetValue(m_monitoredPowerGrid, out islandingDeviceList))
                    {
                        lock (islandingDeviceList)
                        {
                            string strDeviceName;
                            m_measurementDeviceDictionary.TryGetValue(measurementID, out strDeviceName);

                            if (islandingDeviceList.Contains(strDeviceName))
                            {
                                //m_csvStream.Write("islandingDeviceList  contains device {0} at {1} \n", strDeviceName, m.Timestamp.ToString("dd-MMM-yyyy HH:mm:ss.fff"));
                                return true;
                            }
                            else
                            {
                                return false;
                            }
                        }
                    }
                    else //if there is no record of islandingDevice list per this interconnection
                    {
                        return false;
                    }


                }
        */
        //to exclude islanding units for event detection - end


        /// <summary>
        /// Publishes the <see cref="IFrame"/> of time-aligned collection of <see cref="IMeasurement"/> values that arrived within the
        /// adapter's defined <see cref="ConcentratorBase.LagTime"/>.
        /// </summary>
        /// <param name="frame"><see cref="IFrame"/> of measurements with the same timestamp that arrived within <see cref="ConcentratorBase.LagTime"/> that are ready for processing.</param>
        /// <param name="index">Index of <see cref="IFrame"/> within a second ranging from zero to <c><see cref="ConcentratorBase.FramesPerSecond"/> - 1</c>.</param>
        protected override void PublishFrame(IFrame frame, int index)
        {
            MeasurementKey[] inputMeasurements = InputMeasurementKeys;
            //double averageFrequency = double.NaN;

            // Increment frame counter
            m_count++;

            if (m_alarmProhibitCounter > 0)
                m_alarmProhibitCounter--;


            m_noDataCheckCounter++;

            //***********************Update Buffer Data***********************
            // For keep record of data before the event time. If there is no trigger, keep m_bufferPreSize data, 
            // If event is triggered, keep update the data buffer, until the timestamp of the frame is m_bufferPostSize
            // seconds later.
            foreach (KeyValuePair<MeasurementKey, IMeasurement> measurement in frame.Measurements)
            {
                uint measurementID = measurement.Key.ID;
                List<Tuple<DateTime, double>> pmuUnitData = null;
                Tuple<DateTime, double> tupleTmp = new Tuple<DateTime, double>(frame.Timestamp, measurement.Value.AdjustedValue);
                if (m_bufferDataDictionary.TryGetValue(measurementID, out pmuUnitData))
                { 
                    if (!m_eventFlag)
                    {
                        if (pmuUnitData.Count == m_bufferPreSize)
                            pmuUnitData.RemoveAt(0);
                    }
                    pmuUnitData.Add(tupleTmp);
                }
                else
                {
                    pmuUnitData = new List<Tuple<DateTime, double>>();
                    pmuUnitData.Add(tupleTmp);
                }
                m_bufferDataDictionary.AddOrUpdate(measurementID, pmuUnitData, (key, oldvalue) => pmuUnitData);
            }
            if ((m_eventFlag) && (frame.Timestamp.CompareTo(m_eventTimeStamp.AddSeconds(m_bufferPostSize)) > 0))
            {
                WriteBufferData(m_eventTimeStamp, m_bufferDataDictionary);
                m_eventFlag = false;
                m_bufferDataDictionary.Clear();
                
            }

                //*********************Step.0********************
                //For every "m_noDataCheckPeriod" worth of time, check whether some measurement id IS in  m_validInputMeasurementKeys but is NOT in the frame
                //if so, then clear up the reference angle list and especially all the voting records
                //the reason to do this is that, since we only loop around the measurement in the current frame
                //we will not clear the old measurements or voting IF SOME MEASUREMENT JUST STOPS coming in
                // and that record will keep triggering the oscillation
                //question: why don't we just clear the voting record while we find there are too many missing data? is this step redundant?
                //answer:ONLY IF there the measurement id IS in the frame, the step about too many missing data will be reached. 
                //this step is to check the measurement ids that JUST STOPS coming in(NOT in the frame)
            if (m_noDataCheckCounter == m_noDataCheckPeriod)
            {
                foreach (MeasurementKey measurementkey in m_validInputMeasurementKeys)
                {
                    IMeasurement measurement;
                    uint measurementID = measurementkey.ID;

                    if (!frame.Measurements.TryGetValue(measurementkey, out measurement)) //if this measurement doesn't exist in current frame
                    {
                        List<double> oldFrequencyValue;
                        m_analysisFrequencyDictionary.TryRemove(measurementID, out oldFrequencyValue);

                        bool oldVote;
                        m_votedDeviceDictionary.TryRemove(measurementID, out oldVote);

                        int detectedExcursions;
                        m_detectedExcursionsDictionary.TryRemove(measurementID, out detectedExcursions);

                        /*for debug - start
                        string strDeviceName;
                        m_measurementDeviceDictionary.TryGetValue(measurementID, out strDeviceName);
                        m_csvStream.Write("\n clean out old junk of device {0} at {1}", strDeviceName, frame.Timestamp.ToString("dd-MMM-yyyy HH:mm:ss.fff"));
                        //for debug - end*/
                    }

                }
                m_noDataCheckCounter = 0;
            }



            //*********************Step.1********************
            //put current measurement to m_analysisFrequencyDictionary - start
            foreach (KeyValuePair<MeasurementKey, IMeasurement> measurement in frame.Measurements)
            {
                uint measurementID = measurement.Key.ID;
                List<double> frequencylist = null;

                if (m_analysisFrequencyDictionary.TryGetValue(measurementID, out frequencylist))
                {
                    //compare the last timestamp of the device with current timestamp
                    Ticks lastTimestamp;
                    m_lastTimestampDictionary.TryGetValue(measurementID, out lastTimestamp);
                    double lastTimestampSecond = Ticks.ToSeconds(lastTimestamp);
                    double currentTimestampSecond = Ticks.ToSeconds(frame.Timestamp);
                    double timestampDifference = currentTimestampSecond - lastTimestampSecond;


                    // if the data in frequencylist is too old, clear the frequency list
                    int dataOldThreshold = m_analysisWindowSize / FramesPerSecond;

                    if (timestampDifference > dataOldThreshold)
                    {
                        frequencylist.Clear();

                    }
                    //added by Zoe to debug - start
                    //m_csvStream.Write("\n lastTimestampSecond={0}, currentTimestampSecond={1} \n", lastTimestampSecond, currentTimestampSecond);
                    //added by Zoe to debug - end

                    //add frequency
                    frequencylist.Add(measurement.Value.AdjustedValue);

                    //added by Zoe to debug - start
                    //m_csvStream.Write("\n measurementid={0} frequencyvalue ={1} !\n", measurementID, measurement.Value.AdjustedValue);
                    //added by Zoe to debug - end   

                }
                else //if measurement key is not in the dictionary yet
                {
                    frequencylist = new List<double>();
                    frequencylist.Add(measurement.Value.AdjustedValue);
                    m_analysisFrequencyDictionary.TryAdd(measurementID, frequencylist);

                    //added by Zoe to debug - start
                    //m_csvStream.Write("\n measurementid={0} frequencyvalue ={1}!\n", measurementID, measurement.Value.AdjustedValue);
                    //added by Zoe to debug - end

                }

                // Track new frequency and its timestamp
                // m_frequencies.Add(averageFrequency);
                m_lastTimestampDictionary.AddOrUpdate(measurementID, frame.Timestamp, (key, oldvalue) => frame.Timestamp);


                // Maintain analysis window size
                while (frequencylist.Count > m_analysisWindowSize)
                {
                    frequencylist.RemoveAt(0);

                }
            }
            //put current measurement to m_analysisFrequencyMatrix - end
            lock (m_timeStamps)
            {
                m_timeStamps.Add(frame.Timestamp);
                while (m_timeStamps.Count > m_analysisWindowSize)
                {
                    m_timeStamps.RemoveAt(0);
                }
                m_firstTimeStamp = m_timeStamps[0];
            }
            //added by Zoe to debug - start
            //m_csvStream.Write("\n m_timeStamps[0]={0}\n", m_timeStamps[0].ToString("dd-MMM-yyyy HH:mm:ss.fff"));
            //added by Zoe to debug - end

            //*********************Step.2********************
            //perform event detection,
            //1. dfdt analysis 2. voting mechanism
            //skip the dfdt analysis within the m_analysisInterval
            if (m_count % m_analysisInterval != 0)
            {
                //added by Zoe to debug - start
                //m_csvStream.Write("\n m_count={0} \n", m_count);
                //added by Zoe to debug - end
                return;
            }
            else
            {
                m_count = 0;
            }


            //check the dfdt every m_analysisInterval and when there are m_analysisWindowSize of frames already received
            // if (m_count % m_analysisInterval == 0 && m_frequencies.Count == m_analysisWindowSize)
            //check the frequency excursion

            foreach (KeyValuePair<uint, List<double>> frequencylistperdevice in m_analysisFrequencyDictionary)
            {
                uint measurementID = frequencylistperdevice.Key;
                List<double> frequencylist = frequencylistperdevice.Value;

                //added by Zoe to debug - start
                // m_csvStream.Write("\n frequencylist.Count ={0} \n", frequencylist.Count);
                //added by Zoe to debug - end

                if (frequencylist.Count != m_analysisWindowSize)
                {
                    continue;  //exit current iteration
                }

                //check whether a voting period has passed or it is still in alarm prohibit period,
                //if the voting period has passed
                //then clear the voting record
 //               double votingTimestampSecond = Ticks.ToSeconds(m_firstVotingTime.Ticks); // debug- by Ellen. these lines can be replaced. 
 //               double currentTimestampSecond = Ticks.ToSeconds(m_firstTimeStamp.Ticks);
 //               double timestampDifference = currentTimestampSecond - votingTimestampSecond;
                if ( m_firstTimeStamp.CompareTo(m_firstVotingTime)>0 || m_alarmProhibitCounter>0)
 //               if (timestampDifference >= m_votingPeriod || m_alarmProhibitCounter > 0) // clear vote
                {
                    //added by Zoe to debug - start
                    bool voted;
                    m_votedDeviceDictionary.TryGetValue(measurementID, out voted);
                    if (voted)
                    {
                        //clear the detected excursion to restart the internal consecutive detection check
                        m_detectedExcursionsDictionary.AddOrUpdate(measurementID, 0, (key, oldValue) => 0);
                        /*
                        string strDeviceName;
                        m_measurementDeviceDictionary.TryGetValue(measurementID, out strDeviceName);
                        m_csvStream.Write("\n CLEAR voting record Device:{0} VotingTime={1} CurrentTime = {2}", strDeviceName, m_firstVotingTime.ToString("dd-MMM-yyyy HH:mm:ss.fff"), m_firstTimeStamp.ToString("dd-MMM-yyyy HH:mm:ss.fff"));
                    */
                    }
                    //added by Zoe to debug - end

                    m_votedDeviceDictionary.AddOrUpdate(measurementID, false, (key, oldValue) => false);

                }

                //median method - start
                //frequencylist length: m_analysisWindowSize (second*FramesPerSecond) e.g. 5second with frame per second 10 Hz-> m_analysiswindowSize = 40
                //median of the first second in frequencylist: 
                int index1 = FramesPerSecond / 2 - 1;
                int index2 = FramesPerSecond / 2;
                List<double> firstsecondfreq = frequencylist.GetRange(0, FramesPerSecond);
                firstsecondfreq.Sort();
                double frequency1 = (firstsecondfreq[index1] + firstsecondfreq[index2]) / 2;
                //e.g. FramesPerSecond = 10, (frequencylist[4]+frequencylist[5])/2
                //median of the last second 
                //(frequencylist[m_analysisWindowSize - FramesPerSecond/2 + 1] + frequencylist[m_analysisWindowSize - FramesPerSecond/2])/2
                //e.g. FramesPerSecond = 10, (frequencylist[34]+frequencylist[35])/2
                List<double> lastsecondfreq = frequencylist.GetRange(m_analysisWindowSize - FramesPerSecond, FramesPerSecond);
                lastsecondfreq.Sort();
                double frequency2 = (lastsecondfreq[index1] + lastsecondfreq[index2]) / 2;
                //if m_analysisWindowSize is 5 second(m_analysisWindowSize value at this point will be 5*FrameperSecond)
                //frequency1 is the median frequency of no.1 second
                //frequency2 is the median frequency of no.5 second
                //note that the m_deltaTime here is 4 
                // median method end */


                double frequencyDelta = 0.0D, estimatedSize = 0.0D, DfDt = 0.0D;
                EventType typeofExcursion = EventType.GenerationTrip;
        //        bool warningSignaled = false;

                if (!double.IsNaN(frequency1) && !double.IsNaN(frequency2))
                {
                    frequencyDelta = frequency1 - frequency2;
                    DfDt = frequencyDelta / m_deltaTime;
                    //added by Zoe to debug - start
                    // m_csvStream.Write("\n measurementid={0} frequency1 ={1} frequency2 = {2} m_deltaTime = {3} \n", measurementID, frequency1, frequency2, m_deltaTime);
                    //added by Zoe to debug - end

                    //if dfdt is over the triggerthreshold
                    if (Math.Abs(DfDt) < m_estimateTriggerThreshold)
                    {

                        // m_detectedExcursions++;
                        m_detectedExcursionsDictionary.AddOrUpdate(measurementID, 1, (key, oldValue) => oldValue + 1);


                        //added by Zoe to debug - start
                        m_startedvoting = true;
                        int detecteExcur;
                        m_detectedExcursionsDictionary.TryGetValue(measurementID, out detecteExcur);
                        /*
                        string strDeviceName;
                        m_measurementDeviceDictionary.TryGetValue(measurementID, out strDeviceName);
                        //m_csvStream.Write("\n larger...dfdt={0} device={1} detectedExcursion={2} timestamp={3}\n", DfDt, strDeviceName, detecteExcur, m_timeStamps[0].ToString("dd-MMM-yyyy HH:mm:ss.fff"));
                        m_csvStream.Write("\n Device:{0} dfdt:{1}  DetectedExcursion:{2} Timestamp={3}", strDeviceName, DfDt, detecteExcur, m_firstTimeStamp.ToString("dd-MMM-yyyy HH:mm:ss.fff"));
                        */
                        //added by Zoe to debug - end

                    }
                    else
                    {
                        m_detectedExcursionsDictionary.AddOrUpdate(measurementID, 0, (key, oldValue) => 0);
                        /*
                        //added by Zoe to debug - start
                        m_startedvoting = false;
                        int detecteExcur;
                        m_detectedExcursionsDictionary.TryGetValue(measurementID, out detecteExcur);
                        m_csvStream.Write("\n else...dfdt={0} measurementid={1} detectedExcursion={2} timestamp={3}\n", DfDt, measurementID, detecteExcur, m_timeStamps[0].ToString("dd-MMM-yyyy HH:mm:ss.fff"));
                        //added by Zoe to debug - end
                         */
                    }

                    //if dfdt has over the triggerthreshold consecutively

                    int detectedExcursions;
                    m_detectedExcursionsDictionary.TryGetValue(measurementID, out detectedExcursions);

                    int votedDeviceCount;

                    if (detectedExcursions >= m_consecutiveDetections)
                    {
                        m_votedDeviceDictionary.AddOrUpdate(measurementID, true, (key, oldValue) => true);

                        votedDeviceCount = m_votedDeviceDictionary.Count(p => p.Value == true);

                        //if one device just initiate the voting
                        if (votedDeviceCount == 1)
                        {
                            m_firstVotingTime = m_firstTimeStamp;
                        }
                        /*
                        //added by Zoe to debug - start
                        string strDeviceName;
                        m_measurementDeviceDictionary.TryGetValue(measurementID, out strDeviceName);
                        m_csvStream.Write("\n device={0} over threshold consecutively!\n", strDeviceName);
                        //added by Zoe to debug - end
                         * */

                    }

                    votedDeviceCount = m_votedDeviceDictionary.Count(p => p.Value == true);


                    //if enough devices have voted for the event triggering
                    if (votedDeviceCount >= m_votedDeviceThreshold)
                    {
                        typeofExcursion = (frequency1 > frequency2 ? EventType.GenerationTrip : EventType.LoadShedding);
                  //      estimatedSize = Math.Abs(frequencyDelta) * m_powerEstimateRatio;//not accurate, this is only for event size in the time of analysis window
                  // delected by Ellen. The Amount estimation is not included in this tool

                        // Display frequency excursion detection warning
                        if (m_alarmProhibitCounter == 0)
                        {
                            //added by Zoe to debug - start  
                      //      m_csvStream.Write("\n Vote Number: {0} ", votedDeviceCount);
                            //added by Zoe to debug - end
                            m_eventFlag = true; m_eventTimeStamp = m_firstTimeStamp;
                            SendOutEventWarning(m_firstTimeStamp, m_firstVotingTime, frequencyDelta, typeofExcursion, estimatedSize);
                            m_alarmProhibitCounter = m_alarmProhibitPeriod;
                            /* delectd by Ellen, if it needs to filter small trip, active it and the amount estimation both again
                           if (estimatedSize > m_eventAmountCutoffThreshold) //added by Zoe
                            {
                                m_eventFlag = true; m_eventTimeStamp = m_firstTimeStamp;
                                SendOutEventWarning(m_firstTimeStamp, m_firstVotingTime, frequencyDelta, typeofExcursion, estimatedSize);
                                m_alarmProhibitCounter = m_alarmProhibitPeriod;
                            }
                            */

                        }
                   //     warningSignaled = true;

                    }
                }
            }

        }

        private void SendOutEventWarning(DateTime triggeringtime, DateTime firstvotingtime, double delta, EventType typeOfExcursion, double totalAmount)
        {
            OnStatusMessage("WARNING: Frequency excursion detected!\r\n   Time = {0}\r\n     Delta = {1}\r\n   Type = {2}\r\n    Estimated Size = {3}MW\r\n", triggeringtime.ToString("dd-MMM-yyyy HH:mm:ss.fff"), delta, typeOfExcursion, totalAmount.ToString("0.00"));

       //     m_csvStream.Write("Event detected!\r\n   TriggeringTime = {1}\r\n     FirstVotingTime = {2}   Delta = {3}\r\n   Type = {4}\r\n    Estimated Size = {5}MW\r\n", triggeringtime.ToString("dd-MMM-yyyy HH:mm:ss.fff"), firstvotingtime.ToString("dd-MMM-yyyy HH:mm:ss.fff"), delta, typeOfExcursion, totalAmount.ToString("0.00"));
      //      m_csvStream.Flush();
            // write buffer data

            // Dump data

            //call triangulation in Dump data. 




        }

        private void WriteBufferData(DateTime triggeringtime, ConcurrentDictionary<uint, List<Tuple<DateTime, double>>> m_bufferDataDictionary)
        {
            // define txt filenames
            string preFix = triggeringtime.ToString("yyyyMMdd-HHmmss");
            List<Tuple<double, double>> downSampledData = new List<Tuple<double, double>>();
            foreach (uint key in m_bufferDataDictionary.Keys)
            {
                downSampledData = new List<Tuple<double, double>>();
                string fileName = "";
                fileName = "\\"+preFix + "-" + key.ToString() + ".txt";
                // Down sample PMU buffer data into tens per second
                DownSamplePMUData(m_bufferDataDictionary[key], downSampledData);
                // write txt files
                List<String> lines = new List<String>();
                for (int i=0; i< downSampledData.Count; i++)
                {
                    lines.Add(downSampledData[i].Item1.ToString("F1").PadLeft(5) + "\t" + downSampledData[i].Item2.ToString("F4"));
                    
                }
                File.AppendAllLines(Directory.GetCurrentDirectory() + fileName, lines);
                System.GC.Collect();
            }

        }
        
        private void DownSamplePMUData (List<Tuple<DateTime, double>> data, List<Tuple<double, double>> downSampledData)
        {
            DateTime lastStamp = DateTime.MinValue;
            int tupleCnt = 0; List<double> freqlist = new List<double>();
            foreach (Tuple<DateTime, double> item in data)
            {
                tupleCnt++;
                DateTime tmp = item.Item1;
                // truncate milliseconds to subsecond
                DateTime truncated = tmp.AddMilliseconds(-(tmp.Millisecond % 100));

                int msec1 = truncated.Millisecond / 100;
                int msec2 = lastStamp.Millisecond / 100;
                // If current trancated millisecond equals to the last stamp subsecond, and the lastStamp has been updated,
                // collect the frequency value and do not change the time stamp.
                if (msec1 == msec2 && (lastStamp.Year > 2010))
                {
                    // in the same subsec
                    freqlist.Add(item.Item2);

                }
                else // if the subsecond is changed
                {
                    // update the mean frequency of the previous second
                    if (freqlist.Count > 0)
                    {
                        double timestamp = (lastStamp.Month * 10000000 + lastStamp.Day * 100000 + lastStamp.Hour * 3600 + lastStamp.Minute * 60 + lastStamp.Second + 0.1 * lastStamp.Millisecond / 100);
                        double freq = freqlist.Average();
                        var txtItem = new Tuple<double, double>(timestamp, freq);
                        downSampledData.Add(txtItem);
                    }
                    // Update the last time stamp and the frequency list.
                    lastStamp = truncated;
                    freqlist = new List<double>();
                    freqlist.Add(item.Item2);


                }
                // If it comes to the last frame, calcuate the mean frequency value of the last second
                if ((tupleCnt == data.Count) && (lastStamp.Year > 2010))
                {
                    double timestamp = (lastStamp.Month * 10000000 + lastStamp.Day * 100000 + lastStamp.Hour * 3600 + lastStamp.Minute * 60 + lastStamp.Second + 0.1 * lastStamp.Millisecond / 100);
                    double freq = freqlist.Average();
                    var txtItem = new Tuple<double, double>(timestamp, freq);
                    downSampledData.Add(txtItem);

                }
              
            }
            for (int i = 0; i < downSampledData.Count; i++)
            {
                Console.WriteLine(downSampledData[i].Item1 + "   " + downSampledData[i].Item2);
            }

        }
       
        #endregion

    }
}
